<?php

$num1 = 4;
$num2 = 6;

if(($num1+$num2)/2 >= 5){
    echo "Aprobado";
}else{
    echo "Suspendido";
}

?>