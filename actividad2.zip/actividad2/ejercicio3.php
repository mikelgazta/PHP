<?php

$pi = 3.14;
$r = 5;

echo "El perimetro es: <br>".(2*$pi*$r)."<br>";
echo "El area es: <br>".($pi*$r*$r);
?>