<?php
/*
$numbers = array(4, 6, 2, 22, 11);

sort($numbers);
echo "Array en orden ascendente<br>";
$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}

echo "Array en orden descendente<br>";
rsort($numbers);
$arrlength = count($numbers);
for($x = 0; $x < $arrlength; $x++) {
    echo $numbers[$x];
    echo "<br>";
}
*/

$a = 3;
$b = 4;
$c = 5;

$mayor

if(($a<$b)&&($a<$b)){
    $mayor = $a;
}elseif()






?>