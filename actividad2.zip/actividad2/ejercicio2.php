<?php
$cad1 = "Me muero de hambre";
$cad2 = "Quiero comida";

echo $cad1." ".$cad2;
?>