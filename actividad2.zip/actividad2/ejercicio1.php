<?php

$num1 = 3;
$num2 = 2;

echo "La suma de los numeros: <br>";
echo $num1." + ".$num2 ." = ".($num1+$num2)."<br>";

echo "La resta de los numeros:<br>"; 
echo $num1." + ".$num2 ." = ".($num1-$num2)."<br>";

echo "La division de los numeros: <br>";
echo $num1." + ".$num2 ." = ".($num1/$num2)."<br>"; 

echo "El modulo de los numeros: <br>";
echo $num1." + ".$num2 ." = ".($num1%$num2)."<br>"; 
?>