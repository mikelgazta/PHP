<?php

$num = 4;

if(($num % 2) == 0 ){
    echo "El numero es par";    
}else{
    echo "El numero es impar";
}

?>